# ADR 0007 — bounded published snapshot segments

Status: **PROPOSED — requires an explicit architecture/admission decision**.
No production schema, snapshot payload format, public reader or migration has
been changed for this proposal. SCALE-001 remains NOT QUALIFIED.

## Reproduced problem and rejected shortcuts

The existing owned 50k final-snapshot job fails the unchanged 1,000,000-node
sanitizer guard before publication. The new direct reproduction uses complete
metric rows from the preserved 30k snapshot, cycles them to 50k and calls the
actual sanitizer without modifying its arguments. This is direct guard evidence,
not a new full-job/cgroup result. Commands and receipts are recorded in the
Commercial V1 progress/evidence work root.

`backend/domain.py:persist_analysis` captures `quality_metrics`, constructs the
final full snapshot and sanitizes it. `backend/quality_domain.py:persist` also
stores complete quality data. `Generation.validate` hydrates complete Record
JSON, checks relationships and hashes its canonical document. SQLAlchemy must
bind a complete JSON string; the four original graph indexes evaluate against
that full string even when their graph keys are absent.

Preserving only a small descriptor without adapting readers would lose logical
output. Increasing the sanitizer guard, dropping metrics, bypassing validation,
publishing partial state as COMPLETE, or adopting a rejected index projection is
not an acceptable correction.

## Smallest plausible direction

Use a **new, explicit immutable snapshot format for new captures only**, with
bounded authenticated content segments for large observation arrays. Keep the
original Record table, graph-key JSON fields, four indexes and read ordering.
Existing inline snapshots remain unchanged and readable.

Reuse persistent encrypted content-object primitives only after proving their
ownership, retention and backup contracts for this purpose. A permanent segment
must bind organization, repository, snapshot/generation, field, ordinal, count,
codec version and content digest in its authenticated identity. A complete
manifest admits exactly its segment inventory, order and logical hashes.
Staged objects remain private; publication atomically admits the parent and its
complete authenticated references. Retry is idempotent; cancellation/exhaustion
cannot publish dangling references. GC must distinguish abandoned private
objects from permanently referenced published objects.

**Do not reuse expiring GenerationContextPart/GenerationChunk rows as permanent
snapshot storage.** Their normal 72-hour expiry intentionally removes private
recovery data even for published generations. Temporary EncryptedRows owners
also have attempt-local lifetimes. Either would create dangling snapshots.

## Decision requiring approval

The current sanitizer's million-node rule applies to one complete materialized
document. Segmenting changes that admission/persistence contract even if every
segment and manifest retains the existing node/depth/byte guards. It therefore
requires a versioned, reviewed policy defining aggregate encrypted quota,
per-row bounds, descriptor inventory, complete verification and permanent
retention. It must not be introduced as an invisible per-page reset of a global
guard. No existing memory, time, spill or checkpoint quota may be raised.

Approval must also settle the logical read contract. Existing consumers include:

- Record/source inspector and ordinary JSON/SQLAlchemy serialization;
- `snapshot_context.comparison_snapshot` / `quality_fields` SQL JSON projections;
- Claim Ledger, graph/correlation/history and BASE/HEAD comparisons;
- typed v1/v2 generation replay and final validation/canonical fingerprints;
- quality metrics APIs, pagination, exports, trust/coverage and source inventory;
- backup/restore, key rotation, retention, forward/reverse migration and all
  tenant/private-generation visibility rules.

Readers cannot assume a descriptor is an array. A compatibility resolver or
versioned API must preserve complete values, order, typed references and all
documented output semantics. Streaming HTTP JSON must not accidentally perform
full `jsonable_encoder`/Pydantic materialization before sending. No caller may
load all segments merely to satisfy an old `.data` access under the memory gate.

## Required proof before a production proposal

1. A failing intended-success 50k regression with complete owned observations.
2. Complete old-inline versus segmented logical output, ordering and canonical
   digest equality; v1/v2 receipt and legacy snapshot compatibility.
3. Missing/swapped/corrupt/cross-tenant pages, quota overflow, key rotation,
   partial writes, cancellation and actual process-exit recovery fail closed.
4. No orphan publication; immutable previous generations/pointers/audit history
   remain intact. Segment expiry cannot remove published data.
5. Supported API/frontend readers, exports, SQL projections and BASE/HEAD
   comparisons work through the real versioned path.
6. Fresh-process small/10k/50k resource measurements, then the separately
   authorized full pinned Linux 768,000,000-byte, zero-swap acceptance matrix.

The design is not SAFE TO MIGRATE or implemented. Continue independent expiry,
commercial workflow and security validation while this decision is pending.
