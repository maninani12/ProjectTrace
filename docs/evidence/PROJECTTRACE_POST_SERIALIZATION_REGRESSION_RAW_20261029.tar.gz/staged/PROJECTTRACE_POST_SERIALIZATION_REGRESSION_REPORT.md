# ProjectTrace post-serialization regression report

Date: 2026-10-29  
Recorded run branch / HEAD: `codex/scale-001-local-continuation` / `9e21509591bfa5457cc829ebd5637f95be68d573`  
Result: **focused serialization regressions pass; full regression closure not achieved**.

The active chat workspace is projectless and has no Git checkout. The separately visible `C:\Users\sai krishna\OneDrive\Desktop\ProjectTrace` checkout is `main` at `46efd42b77ab1c9bfd48b64647b5d2b394d64c70`, which does not match the task's expected continuation branch and HEAD. In accordance with the preservation instruction, this report and its JSON are delivered in the task output folder rather than written into that mismatched checkout. The test receipts were recorded on the expected continuation checkout.

## Fix review

`backend/generations.py` now sorts set members by canonical JSON spelling using the existing `encoded` callback, ASCII escaping, compact separators, and sorted nested object keys. It preserves the existing `$set` wire shape and membership, leaves mapping insertion order unchanged, and leaves tuple handling unchanged. The regression test in `tests/test_json_export.py` also confirms unsupported objects inside sets still raise the established `TypeError`.

The focused regression matrix covers nested supported values, exact JSON bytes across independent hash seeds, typed export/replay and mutation behavior, snapshot integrity, and unsupported set members. All 69 JSON export tests passed in the full run. No serializer regression appeared in the broad suite. Prior recorded export/sanitizer evidence was 116 passed / 2 failed before the fix and 119 passed afterward. The serializer correction changes no API schema or sanitizer policy. Cross-platform and production-data compatibility are not established here.

## Focused test results

Command per process: `python -m pytest -q --basetemp <unique scratch base> tests/test_json_export.py -k 'typed_context_export_replay_mutations_and_snapshot_integrity or generation_set_encoding_is_deterministic or unsupported_types_and_keys_still_rejected'`.

Normal environment and `PYTHONHASHSEED` values 0, 1, 2, 3, 7, 17, and 42 each produced **4 passed, 65 deselected**. Serialized JSON remained byte-for-byte stable across the eight processes. Complete `tests/test_json_export.py`: **69 passed**. Snapshot materialization cases without the 50k fixture: **3 passed** (none, 10k, 30k); the known 50k final snapshot rejection workload was not rerun.

## Full backend suite

Environment: Windows, Python 3.14.3, pytest 9.1.1, Ruff 0.16.10; documented project venv. Suite ran in demo/synchronous mode with DB, blob, source, temp, and key paths redirected to scratch. Graph prototype tests used isolated disposable scratch roots; original DB fixtures were not targeted for writes.

Command: `python -m pytest -q --basetemp <scratch> --deselect tests/test_snapshot_materialization_profile.py::test_owned_final_snapshot_profile[50000] --junitxml <scratch>/full-suite.xml`.

Result: **1,055 passed, 9 failed, 21 skipped, 2 error events, 1 deselected**; 1,086 cases executed. Two error events (setup and teardown) belong to one parser sandbox case.

Failure triage:

- Three first-run graph index failures (`test_frozen_rows_and_writes_are_never_redefined` for partial, validated_partial, guarded) were due to a missing compatibility fixture in the scratch layout. The scratch fixture was added; those cases passed on the corrected graph opt-in rerun.
- Six remaining failures are known graph candidate behavior already present in existing graph evidence: three `test_extra_version_filter_preserves_complete_baseline_sequence` parameterizations; `test_natural_key_only_update_preserves_projection_metadata`; and `test_filtered_mixed_sequences_match_complete_baseline[version]` plus `test_rowid_read_namespace_is_preserved`. They also failed in the corrected opt-in graph rerun (64 passed, 6 failed) and are unrelated to serialization.
- One parser sandbox case caused two error events because Windows rejected an environment variable exceeding 32,767 characters. This is a host limitation.

The 21 skips comprise 16 PostgreSQL tests requiring an explicit disposable `PROJECTTRACE_TEST_POSTGRES_URL`, five Linux-only tests (two archive transport, one unnamed SQLite lifecycle, two parser pipe transport). No PostgreSQL service was configured and no platform safeguard was bypassed. Per-module pass/fail/error/skip counts and full JUnit failure/skip details are in the accompanying JSON.

## Recovered graph tests and integration suite

With the supported graph ownership opt-in and scratch-local storage, the corrected graph test selection yielded **64 passed, 6 failed, 0 skipped**: graph index recovery 17/3, scalar projection 37/1, scalar reading 10/2. Failures are the known graph candidate cases above.

The separate `integration_tests` attempt yielded **58 setup errors and 4 skips**. Its fixture explicitly requires Linux and refuses to run on Windows; four broker tests also require disposable CI Redis/PostgreSQL services. No fixture guard was bypassed.

## Other checks

- Frontend Vitest: **12 files passed, 49 tests passed**, 146.65s.
- `ruff check backend analyzers integrations workers tests scripts`: passed.
- `python -m compileall -q backend analyzers integrations workers scripts tests integration_tests`: passed.
- `git diff --check`: passed on the recorded run checkout.
- Existing determinism/policy JSON parsed; the new evidence JSON is validated after writing.

## Preservation and decision boundary

Recorded run checkout branch / HEAD: `codex/scale-001-local-continuation` / `9e21509591bfa5457cc829ebd5637f95be68d573`. Existing dirty worktree state was preserved; no reset, clean, checkout, commit, push, migration, or original database write occurred. The four database hashes matched their recorded baselines:

| Database | SHA-256 |
|---|---|
| 10k | `465441f1d2c7d6ca3d7427c79dd55e57c350bee451b60a66b8e0e92f5a1d1b` |
| 147 | `97aeda34f1cb1b1d67784926c2140c3c27063585ae135fbb39e22643edce94d6` |
| 30k | `c7313fd66baa9e23ec5f5a7e9bdb8003554d086796c101be14f8d02d6ee5e9a4` |
| prior | `14a15885488462c687ce2581807ea56ecb2145b98bc58d67f6e2aad3ba9a5627` |

Aggregate sanitizer cap stays 1,000,000; recorded 50k fixture remains 1,115,947 nodes and rejected during final sanitization. Option A remains `PENDING_PRODUCT_OWNER_APPROVAL`; SCALE-001 remains **NOT QUALIFIED**; Commercial V1 remains **DEVELOPMENT IN PROGRESS**. No Linux, distributed, broker recovery, PostgreSQL, concurrency, tenant isolation, or resource qualification is claimed. Full closure remains open due six known graph failures, Windows platform constraints, and unavailable PostgreSQL.

## Evidence

Structured inventory and receipts: `evidence/PROJECTTRACE_POST_SERIALIZATION_REGRESSION.json`. Raw test receipts remain in `work/post-serialization-closure/` in the task workspace.

## Full backend module inventory

Each row is a pytest test-module classname from the JUnit receipt. `Errored cases` counts testcases (the parser sandbox testcase emitted two error events).

| Module | Passed | Failed | Errored cases | Skipped |
|---|---:|---:|---:|---:|
| `tests.test_accuracy_hardening` | 7 | 0 | 0 | 0 |
| `tests.test_administration` | 5 | 0 | 0 | 0 |
| `tests.test_administration_acceptance` | 13 | 0 | 0 | 0 |
| `tests.test_administration_api` | 5 | 0 | 0 | 0 |
| `tests.test_administration_features` | 5 | 0 | 0 | 0 |
| `tests.test_administration_operations` | 6 | 0 | 0 | 0 |
| `tests.test_administration_postgresql` | 0 | 0 | 0 | 1 |
| `tests.test_administration_workers` | 4 | 0 | 0 | 0 |
| `tests.test_advisory_graph` | 3 | 0 | 0 | 0 |
| `tests.test_advisory_worker` | 1 | 0 | 0 | 0 |
| `tests.test_analysis_checkpoints` | 7 | 0 | 0 | 0 |
| `tests.test_analysis_coverage` | 21 | 0 | 0 | 0 |
| `tests.test_analysis_performance` | 19 | 0 | 0 | 0 |
| `tests.test_analyzer_evolution` | 35 | 0 | 0 | 0 |
| `tests.test_analyzers` | 26 | 0 | 0 | 0 |
| `tests.test_api` | 19 | 0 | 0 | 0 |
| `tests.test_archive_safety` | 9 | 0 | 0 | 0 |
| `tests.test_archive_transport` | 1 | 0 | 0 | 2 |
| `tests.test_auth_drift` | 10 | 0 | 0 | 0 |
| `tests.test_auth_during_capture` | 3 | 0 | 0 | 0 |
| `tests.test_backup` | 1 | 0 | 0 | 0 |
| `tests.test_checkpoint_pages` | 29 | 0 | 0 | 0 |
| `tests.test_code_quality` | 37 | 0 | 0 | 0 |
| `tests.test_configuration_drift` | 5 | 0 | 0 | 0 |
| `tests.test_correlation_performance` | 5 | 0 | 0 | 0 |
| `tests.test_dev_workers` | 4 | 0 | 0 | 0 |
| `tests.test_engineering_changes` | 2 | 0 | 0 | 0 |
| `tests.test_enterprise_trust` | 33 | 0 | 0 | 0 |
| `tests.test_fair_scheduling` | 7 | 0 | 0 | 0 |
| `tests.test_finding_identity` | 9 | 0 | 0 | 0 |
| `tests.test_gateway` | 3 | 0 | 0 | 0 |
| `tests.test_generation_context` | 18 | 0 | 0 | 0 |
| `tests.test_generation_map_iteration` | 33 | 0 | 0 | 0 |
| `tests.test_generation_maps` | 19 | 0 | 0 | 0 |
| `tests.test_generations` | 34 | 0 | 0 | 0 |
| `tests.test_ghes` | 11 | 0 | 0 | 0 |
| `tests.test_github` | 4 | 0 | 0 | 0 |
| `tests.test_graph_impact` | 8 | 0 | 0 | 0 |
| `tests.test_graph_index_recovery` | 14 | 6 | 0 | 0 |
| `tests.test_graph_pages` | 2 | 0 | 0 | 0 |
| `tests.test_graph_scalar_projection` | 37 | 1 | 0 | 0 |
| `tests.test_graph_scalar_reading` | 10 | 2 | 0 | 0 |
| `tests.test_iac_partitions` | 1 | 0 | 0 | 0 |
| `tests.test_import_reliability` | 9 | 0 | 0 | 0 |
| `tests.test_indexed_workspace_queries` | 4 | 0 | 0 | 0 |
| `tests.test_infrastructure_deep` | 6 | 0 | 0 | 0 |
| `tests.test_json_export` | 69 | 0 | 0 | 0 |
| `tests.test_lease_renewal_race` | 4 | 0 | 0 | 0 |
| `tests.test_lexical_boundary` | 44 | 0 | 0 | 0 |
| `tests.test_local_jobs` | 2 | 0 | 0 | 0 |
| `tests.test_migrations` | 6 | 0 | 0 | 0 |
| `tests.test_model_registration` | 4 | 0 | 0 | 0 |
| `tests.test_native_artifact_transport` | 14 | 0 | 0 | 0 |
| `tests.test_native_platform` | 23 | 0 | 0 | 0 |
| `tests.test_observation_store` | 13 | 0 | 0 | 1 |
| `tests.test_oidc_lifecycle` | 8 | 0 | 0 | 0 |
| `tests.test_onboarding` | 10 | 0 | 0 | 0 |
| `tests.test_openapi_batches` | 15 | 0 | 0 | 0 |
| `tests.test_parser_sandbox` | 12 | 0 | 1 | 2 |
| `tests.test_postgresql_integration` | 0 | 0 | 0 | 13 |
| `tests.test_private_operations` | 5 | 0 | 0 | 0 |
| `tests.test_public_auth` | 1 | 0 | 0 | 0 |
| `tests.test_public_github` | 21 | 0 | 0 | 0 |
| `tests.test_publication_units` | 6 | 0 | 0 | 0 |
| `tests.test_quality_profiles` | 8 | 0 | 0 | 0 |
| `tests.test_quality_spill` | 8 | 0 | 0 | 0 |
| `tests.test_queue` | 6 | 0 | 0 | 0 |
| `tests.test_rate_policy` | 4 | 0 | 0 | 0 |
| `tests.test_real_pipeline` | 2 | 0 | 0 | 0 |
| `tests.test_record_identity` | 3 | 0 | 0 | 0 |
| `tests.test_record_scope_integrity` | 3 | 0 | 0 | 0 |
| `tests.test_recovery_boundaries` | 10 | 0 | 0 | 0 |
| `tests.test_recovery_postgresql` | 0 | 0 | 0 | 1 |
| `tests.test_repository_read` | 7 | 0 | 0 | 0 |
| `tests.test_repository_store` | 19 | 0 | 0 | 0 |
| `tests.test_retention_downgrade` | 1 | 0 | 0 | 0 |
| `tests.test_retention_postgresql` | 0 | 0 | 0 | 1 |
| `tests.test_retention_recovery` | 28 | 0 | 0 | 0 |
| `tests.test_sanitization_aggregate_guard` | 3 | 0 | 0 | 0 |
| `tests.test_sanitization_cache` | 3 | 0 | 0 | 0 |
| `tests.test_sanitization_fast_path` | 3 | 0 | 0 | 0 |
| `tests.test_scale_benchmark_integrity` | 2 | 0 | 0 | 0 |
| `tests.test_scale_diagnostics` | 3 | 0 | 0 | 0 |
| `tests.test_scale_metric_ownership` | 5 | 0 | 0 | 0 |
| `tests.test_scale_operation_probe` | 4 | 0 | 0 | 0 |
| `tests.test_scale_output_comparison` | 8 | 0 | 0 | 0 |
| `tests.test_scale_workload_manifest` | 1 | 0 | 0 | 0 |
| `tests.test_scm_batch` | 19 | 0 | 0 | 0 |
| `tests.test_scm_streaming` | 5 | 0 | 0 | 0 |
| `tests.test_scm_webhook` | 28 | 0 | 0 | 0 |
| `tests.test_security_hardening` | 9 | 0 | 0 | 0 |
| `tests.test_signal_index` | 38 | 0 | 0 | 0 |
| `tests.test_snapshot_materialization_profile` | 3 | 0 | 0 | 0 |
| `tests.test_streaming_import` | 4 | 0 | 0 | 0 |
| `tests.test_timeout_recovery` | 5 | 0 | 0 | 0 |
| `tests.test_transport_reliability` | 2 | 0 | 0 | 0 |
| `tests.test_trust_controls` | 3 | 0 | 0 | 0 |
| `tests.test_worker_failure` | 1 | 0 | 0 | 0 |
| `tests.test_workspace_pagination` | 6 | 0 | 0 | 0 |
