"""Package command receipts and source/probe evidence without databases or keys."""

import datetime as dt
import gzip
import hashlib
import json
import tarfile
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPO = Path(r"C:\Users\sai krishna\Projects\ProjectTrace-local")
DEST = REPO / "docs/evidence"
ARCHIVE = DEST / "PROJECTTRACE_COMMERCIAL_V1_LOCAL_2026_10_29_REVIEWED_RAW.tar.gz"
SUMMARY = DEST / "PROJECTTRACE_COMMERCIAL_V1_LOCAL_2026_10_29_REVIEWED.json"


def sha_bytes(data):
    return hashlib.sha256(data).hexdigest()


def sha_file(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def test_result(path):
    root = ET.parse(path).getroot()
    suites = [root] if root.tag == "testsuite" else list(root.iter("testsuite"))
    tests = sum(int(suite.attrib.get("tests", 0)) for suite in suites)
    failures = sum(int(suite.attrib.get("failures", 0)) for suite in suites)
    errors = sum(int(suite.attrib.get("errors", 0)) for suite in suites)
    skipped = sum(int(suite.attrib.get("skipped", 0)) for suite in suites)
    skipped_cases = [
        f"{case.attrib.get('classname')}::{case.attrib.get('name')}"
        for case in root.iter("testcase")
        if case.find("skipped") is not None
    ]
    return {
        "tests": tests,
        "passed": tests - failures - errors - skipped,
        "failures": failures,
        "errors": errors,
        "skipped": skipped,
        "skipped_cases": skipped_cases,
        "seconds": sum(float(suite.attrib.get("time", 0)) for suite in suites),
        "sha256": sha_file(path),
    }


def selected_archive_files():
    files = set(ROOT.glob("*.json")) | set(ROOT.glob("*.xml"))
    for name in (
        "baseline.py",
        "run_command.py",
        "run_components.py",
        "structural_repro.py",
        "browser_workflow.py",
        "preservation_final.py",
        "append_scale_report.py",
        "package_evidence.py",
    ):
        files.add(ROOT / name)
    for directory in ("cpu-original-147", "cpu-original-147-quiet", "cold-original-147"):
        folder = ROOT / directory
        if folder.exists():
            files.update(
                path for path in folder.rglob("*")
                if path.is_file() and path.suffix.lower() in {".json", ".jsonl", ".gz", ".txt", ".csv", ".prof"}
            )
    repo_paths = (
        "PROJECTTRACE_PROGRESS.md",
        "docs/COMMERCIAL_V1_RELEASE_GATES.md",
        "docs/CHECKPOINT_RETENTION_AND_ROLLBACK.md",
        "docs/adr/0007-bounded-published-snapshot-segments.md",
        "docs/SCALE001_GENERATION_MAPS_LOCAL_TECHNICAL_REPORT.md",
        "tests/commercial_snapshot_profile.py",
        "samples/configuration-drift.json",
        "tests/test_configuration_drift.py",
        "frontend/e2e/configuration-drift.spec.ts",
    )
    files.update(REPO / path for path in repo_paths)
    missing = [str(path) for path in files if not path.is_file()]
    if missing:
        raise FileNotFoundError("Missing evidence inputs: " + ", ".join(sorted(missing)))
    return sorted(files, key=lambda path: str(path).lower())


def add_file(archive, path, arcname):
    data = path.read_bytes()
    info = tarfile.TarInfo(arcname)
    info.size = len(data)
    info.mode = 0o644
    info.mtime = 0
    info.uid = info.gid = 0
    info.uname = info.gname = ""
    archive.addfile(info, __import__("io").BytesIO(data))
    return {"path": arcname, "bytes": len(data), "sha256": sha_bytes(data)}


def main():
    if ARCHIVE.exists() or SUMMARY.exists():
        raise ValueError("Never overwrite evidence artifacts.")
    files = selected_archive_files()
    members = []
    with ARCHIVE.open("xb") as raw:
        with gzip.GzipFile(filename="", fileobj=raw, mode="wb", mtime=0) as gz:
            with tarfile.open(fileobj=gz, mode="w|", format=tarfile.PAX_FORMAT) as archive:
                for path in files:
                    if path.is_relative_to(REPO):
                        relative = "repository/" + path.relative_to(REPO).as_posix()
                    else:
                        relative = "work-root/" + path.relative_to(ROOT).as_posix()
                    members.append(add_file(archive, path, relative))
    xml_results = {path.stem: test_result(path) for path in sorted(ROOT.glob("*.xml"))}
    command_results = {}
    for path in sorted(ROOT.glob("*.json")):
        item = read_json(path)
        if isinstance(item, dict) and "command" in item and "exit_code" in item:
            command_results[path.stem] = {
                "exit_code": item.get("exit_code"),
                "seconds": item.get("seconds"),
                "command": item.get("command"),
                "scope": item.get("scope"),
            }
    comparison = {}
    for name in ("outputs-three-phases.json", "outputs-cpu.json", "outputs-cpu-quiet.json"):
        item = read_json(ROOT / name)
        comparison[name] = {"equal": item.get("equal"), "snapshot_count": len(item.get("before", {}).get("snapshots", {}))}
    owned = read_json(ROOT / "owned-three-phases.json")
    owned_value = json.loads(owned["stdout"])
    preserve = read_json(ROOT / "preservation-final-20261029.json")
    report_append = read_json(ROOT / "scale-report-append-receipt.json")
    new_tests = read_json(ROOT / "configuration-drift-final.json")
    browser = read_json(ROOT / "configuration-drift-browser-command.json")
    summary_data = {
        "date": "2026-10-29",
        "branch": "codex/scale-001-local-continuation",
        "head": "9e21509591bfa5457cc829ebd5637f95be68d573",
        "scope": "LOCAL_WINDOWS_DEVELOPMENT_ONLY",
        "commercial_v1": "DEVELOPMENT_IN_PROGRESS_NOT_RELEASE_QUALIFIED",
        "scale001": "NOT_QUALIFIED",
        "remote_workflows_run_for_dirty_tree": False,
        "proposed_adr_0007": "PROPOSED_USER_REQUESTED_REVIEW_FIRST_NO_IMPLEMENTATION_AUTHORIZED",
        "new_configuration_drift_tests": {
            "focused_pytest_exit": new_tests["exit_code"],
            "focused_pytest_result": "7 passed" if new_tests["exit_code"] == 0 else "failed",
            "browser_exit": browser["exit_code"],
            "browser_stdout": browser["stdout"],
            "pytest_initial_temp_failure": read_json(ROOT / "configuration-drift-focused.json")["exit_code"],
            "pytest_first_assertion_failure": read_json(ROOT / "configuration-drift-focused3.json")["exit_code"],
        },
        "test_reports": xml_results,
        "local_command_receipts": command_results,
        "output_equivalence": comparison,
        "owned_cold_warm_incremental": owned_value,
        "preservation_audit": preserve,
        "scale_report_append": report_append,
        "qualification_blockers": [
            "50k complete snapshot still hits the unchanged 1,000,000-node sanitizer guard",
            "PostgreSQL row-lock integration test skipped because no disposable service was configured",
            "Docker desktop-linux daemon unavailable; no local Linux cgroup run",
            "full pinned Linux 768000000-byte zero-swap workload and recovery matrix not run",
            "ADR 0007 segmented snapshot format awaits user proposal review",
        ],
        "archive": {
            "path": "docs/evidence/" + ARCHIVE.name,
            "members": members,
            "member_count": len(members),
            "excluded": ["database files", "encryption keys", "source blobs", "browser screenshots", "process logs"],
        },
    }
    archive_data = ARCHIVE.read_bytes()
    summary_data["archive"]["bytes"] = len(archive_data)
    summary_data["archive"]["sha256"] = sha_bytes(archive_data)
    SUMMARY.write_text(json.dumps(summary_data, indent=2), encoding="utf-8")
    print(json.dumps({
        "summary": str(SUMMARY),
        "summary_sha256": sha_file(SUMMARY),
        "archive": str(ARCHIVE),
        "archive_bytes": len(archive_data),
        "archive_sha256": sha_bytes(archive_data),
        "members": len(members),
        "test_reports": xml_results,
        "output_equivalence": comparison,
        "preservation_pass": preserve["pass"],
    }, indent=2))


if __name__ == "__main__":
    main()
