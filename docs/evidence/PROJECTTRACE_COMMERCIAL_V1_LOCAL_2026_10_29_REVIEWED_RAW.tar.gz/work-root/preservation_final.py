"""Read-only end-of-session audit against the captured local preservation baseline."""

import hashlib
import json
import sqlite3
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPO = Path(r"C:\Users\sai krishna\Projects\ProjectTrace-local")
BASELINE = json.loads((ROOT / "baseline.json").read_text(encoding="utf-8"))
OUTPUT = ROOT / "preservation-final-20261029.json"
ALLOWED_EXISTING_CHANGES = {
    "backend/analysis_checkpoints.py",
    "backend/generations.py",
    "backend/publication_units.py",
    "backend/queue.py",
    "docs/SCALE001_GENERATION_MAPS_LOCAL_TECHNICAL_REPORT.md",
}


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def git(*args):
    return subprocess.check_output(["git", *args], cwd=REPO)


def main():
    target = set(git("ls-files", "--cached", "--others", "--exclude-standard", "-z").decode().split("\0")) - {""}
    changed = []
    for name, expected in BASELINE["source_files"].items():
        path = REPO / name
        if not path.is_file():
            changed.append({"path": name, "change": "missing"})
            continue
        actual = sha(path)
        if actual != expected:
            changed.append({"path": name, "change": "content_changed", "sha256": actual})
    database_results = {}
    for label, entry in BASELINE["original_databases"].items():
        path = Path(entry["path"])
        before = sha(path)
        with sqlite3.connect("file:" + path.as_posix() + "?mode=ro", uri=True) as db:
            integrity = db.execute("PRAGMA integrity_check").fetchone()[0]
            foreign_keys = db.execute("PRAGMA foreign_key_check").fetchall()
            generations = db.execute("SELECT state,count(*) FROM analysis_generations GROUP BY state").fetchall()
            pointers = db.execute("SELECT count(*) FROM published_generations").fetchone()[0]
        after = sha(path)
        database_results[label] = {
            "path": str(path),
            "sha256_before": before,
            "sha256_after": after,
            "same_as_captured_baseline": before == entry["sha256"] == after,
            "integrity": integrity,
            "foreign_key_violations": len(foreign_keys),
            "generation_states": generations,
            "published_pointers": pointers,
        }
    unexpected = [row for row in changed if row["path"] not in ALLOWED_EXISTING_CHANGES]
    result = {
        "branch": git("branch", "--show-current").decode().strip(),
        "head": git("rev-parse", "HEAD").decode().strip(),
        "expected_head": BASELINE["head"],
        "baseline_files_checked": len(BASELINE["source_files"]),
        "changed_baseline_files": changed,
        "unexpected_baseline_file_changes": unexpected,
        "new_nonignored_paths": sorted(target - set(BASELINE["source_files"])),
        "original_databases": database_results,
        "tracked_diff_sha256_now": hashlib.sha256(git("diff", "--binary")).hexdigest(),
        "scope": "LOCAL_READ_ONLY_PRESERVATION_AUDIT",
    }
    result["pass"] = (
        result["branch"] == "codex/scale-001-local-continuation"
        and result["head"] == result["expected_head"]
        and {row["path"] for row in changed} == ALLOWED_EXISTING_CHANGES
        and not unexpected
        and all(
            db["same_as_captured_baseline"] and db["integrity"] == "ok" and db["foreign_key_violations"] == 0
            for db in database_results.values()
        )
    )
    if OUTPUT.exists():
        raise ValueError("Never overwrite the preservation receipt.")
    OUTPUT.write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result, indent=2))
    if not result["pass"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
