"""Fresh direct sanitizer reproduction from an owned immutable snapshot shape."""

import hashlib
import json
import sqlite3
import time
from pathlib import Path

from analyzers.sanitization import metadata
from scripts.benchmark_repository_analysis import process_stats

ROOT = Path(__file__).resolve().parent
manifest = json.loads((ROOT / "baseline.json").read_text(encoding="utf-8"))
source = Path(manifest["original_databases"]["30000"]["path"])
with sqlite3.connect("file:" + source.as_posix() + "?mode=ro", uri=True) as db:
    raw = db.execute("SELECT data FROM records WHERE kind='snapshot' LIMIT 1").fetchone()[0]
value = json.loads(raw)
metrics = value["quality_metrics"]
value["quality_metrics"] = [metrics[index % len(metrics)] for index in range(50000)]
started = time.perf_counter()
try:
    metadata(value)
    outcome = {"failure": None}
except ValueError as error:
    outcome = {"failure": type(error).__name__, "message": str(error)}
assert outcome.get("message") == "Sanitization structure budget exceeded"
receipt = {
    "scope": "OWNED_DIRECT_50K_SNAPSHOT_SANITIZER_REPRODUCTION_NOT_FULL_ANALYSIS",
    "source_sha256": manifest["original_databases"]["30000"]["sha256"],
    "snapshot_json_sha256": hashlib.sha256(raw.encode()).hexdigest(),
    "fixture": "Cycle the original 30k complete metric rows to 50k; preserve all other snapshot fields",
    "metric_rows": 50000,
    "sanitizer_nodes": 1000000,
    "outcome": outcome,
    "seconds": time.perf_counter() - started,
    "process": process_stats(),
    "publication": "NOT_RUN: direct read-only sanitizer call; historical full-job failure remains separate",
}
output = ROOT / "structural-50k.json"
if output.exists():
    raise ValueError("Never overwrite a reproduction receipt.")
output.write_text(json.dumps(receipt, indent=2), encoding="utf-8")
print(json.dumps(receipt))
