"""Exact local command receipts; no experimental plugins or production targets."""

import argparse
import json
import os
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPO = Path(r"C:\Users\sai krishna\Projects\ProjectTrace-local")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("label")
    parser.add_argument("--frontend", action="store_true")
    parser.add_argument("command", nargs=argparse.REMAINDER)
    args = parser.parse_args()
    command = args.command[1:] if args.command[:1] == ["--"] else args.command
    output = ROOT / (args.label + ".json")
    if output.exists():
        raise ValueError("Never overwrite a command receipt.")
    if not args.label.replace("-", "").isalnum():
        raise ValueError("A receipt label must be a simple owned name.")
    runtime = ROOT / "runtime" / args.label
    runtime.mkdir(parents=True)
    env = {
        **os.environ,
        "APP_ENV": "demo",
        "JOB_MODE": "sync",
        "PROJECTTRACE_PARSER_ISOLATION": "development",
        "PYTHONHASHSEED": "0",
        "PYTHONPATH": str(REPO) + os.pathsep + str(ROOT.parent),
        "DATABASE_URL": "sqlite:///" + str(runtime / "bootstrap.db"),
        "ANALYSIS_KEY_FILE": str(runtime / "analysis.key"),
        "SOURCE_BLOB_DIR": str(runtime / "blobs"),
        "SOURCE_UPLOAD_DIR": str(runtime / "uploads"),
    }
    env.pop("SCALE001_INDEX_TEST_MODE", None)
    env.pop("SCALE001_PROTOTYPE_ROOT", None)
    env.pop("ANALYSIS_INPUT_KEY", None)
    env.pop("ANALYSIS_PREVIOUS_KEYS", None)
    started = time.perf_counter()
    try:
        result = subprocess.run(
            command,
            cwd=REPO / "frontend" if args.frontend else REPO,
            env=env,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=600,
        )
        receipt = {"command": command, "exit_code": result.returncode, "stdout": result.stdout, "stderr": result.stderr}
    except subprocess.TimeoutExpired as error:
        receipt = {
            "command": command,
            "exit_code": None,
            "failure": "LOCAL_COMMAND_TIMEOUT_600S",
            "stdout": str(error.stdout or ""),
            "stderr": str(error.stderr or ""),
        }
    except OSError as error:
        receipt = {
            "command": command,
            "exit_code": None,
            "failure": type(error).__name__,
            "stdout": "",
            "stderr": str(error),
        }
    receipt.update(
        seconds=time.perf_counter() - started,
        head=subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=REPO, text=True).strip(),
        cwd=str(REPO / "frontend" if args.frontend else REPO),
        scope="LOCAL_WINDOWS_DEVELOPMENT_ONLY",
        experimental_plugins_enabled=False,
    )
    output.write_text(json.dumps(receipt, indent=2), encoding="utf-8")
    print(
        json.dumps(
            {
                "receipt": str(output),
                "exit_code": receipt["exit_code"],
                "seconds": receipt["seconds"],
                "tail": receipt["stdout"][-1800:],
                "error": receipt["stderr"][-1200:],
            }
        )
    )
    return receipt["exit_code"] if receipt["exit_code"] is not None else 124


if __name__ == "__main__":
    sys.exit(main())
