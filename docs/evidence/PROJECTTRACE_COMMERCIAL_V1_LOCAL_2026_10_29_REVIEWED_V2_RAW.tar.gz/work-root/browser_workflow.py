"""Existing auth-drift browser test against fresh owned backend and UI only."""

import argparse
import json
import os
import socket
import subprocess
import time
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPO = Path(r"C:\Users\sai krishna\Projects\ProjectTrace-local")
NODE = r"C:\Program Files\nodejs\node.exe"
PYTHON = r"C:\Users\sai krishna\OneDrive\Desktop\ProjectTrace\.venv\Scripts\python.exe"
parser = argparse.ArgumentParser()
parser.add_argument("--label", default="browser")
parser.add_argument("files", nargs="*")
args = parser.parse_args()
if not args.label.replace("-", "").isalnum():
    raise ValueError("Owned evidence label is invalid.")
output = ROOT / (args.label + "-command.json")
if output.exists():
    raise ValueError("Never overwrite browser evidence.")
for port in (5181, 8011):
    with socket.socket() as probe:
        probe.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
        probe.bind(("127.0.0.1", port))
base = {key: value for key, value in os.environ.items() if key.upper() in {
    "SYSTEMROOT", "WINDIR", "PATH", "TEMP", "TMP", "USERPROFILE", "LOCALAPPDATA", "APPDATA",
    "PROGRAMFILES", "PROGRAMFILES(X86)", "COMSPEC", "PATHEXT", "NUMBER_OF_PROCESSORS", "PROCESSOR_ARCHITECTURE"}}
env = {**base, "APP_ENV": "demo", "PROJECTTRACE_PARSER_ISOLATION": "development",
       "PROJECTTRACE_API_URL": "http://127.0.0.1:8011", "OSV_ENABLED": "0",
       "PROJECTTRACE_E2E_ISOLATED_API": "1", "PROJECTTRACE_PYTHON": PYTHON,
       "PROJECTTRACE_E2E_RESULTS": str(ROOT / (args.label + "-results.json")),
       "PROJECTTRACE_PROOF": str(ROOT / (args.label + "-proof"))}
for key in ("PROJECTTRACE_BASE_URL", "PROJECTTRACE_ADMIN_QA", "ANALYSIS_INPUT_KEY", "ANALYSIS_PREVIOUS_KEYS"):
    env.pop(key, None)
ui_command = [NODE, "node_modules/vite/bin/vite.js", "--host", "127.0.0.1", "--port", "5181"]
command = [NODE, "node_modules/@playwright/test/cli.js", "test", *(args.files or ["e2e/auth-drift.spec.ts"]),
           "--output=" + str(ROOT / (args.label + "-artifacts"))]
with (ROOT / (args.label + "-owned-ui.log")).open("w", encoding="utf-8") as log:
    ui = subprocess.Popen(ui_command, cwd=REPO / "frontend", env=env, stdout=log,
                          stderr=subprocess.STDOUT, creationflags=subprocess.CREATE_NO_WINDOW)
    try:
        for _ in range(60):
            if ui.poll() is not None:
                raise RuntimeError("Owned UI exited before readiness; inspect owned-ui.log.")
            try:
                with urllib.request.urlopen("http://127.0.0.1:5181", timeout=1) as response:
                    if response.status == 200:
                        break
            except OSError:
                time.sleep(0.2)
        else:
            raise TimeoutError("Owned UI readiness failed.")
        result = subprocess.run(command, cwd=REPO / "frontend", env=env, capture_output=True,
                                text=True, encoding="utf-8", errors="replace", timeout=180)
        receipt = {"scope": "OWNED_WINDOWS_BROWSER_DEVELOPMENT_ONLY", "command": command,
                   "ui_command": ui_command, "exit_code": result.returncode,
                   "stdout": result.stdout, "stderr": result.stderr,
                   "production_or_existing_service_modified": False}
        output.write_text(json.dumps(receipt, indent=2), encoding="utf-8")
        print(json.dumps(receipt))
        if result.returncode:
            raise SystemExit(result.returncode)
    finally:
        if ui.poll() is None:
            ui.terminate()
            ui.wait(timeout=15)
