"""Sequential original-path development measurements; every output is fresh."""

import json
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPO = Path(r"C:\Users\sai krishna\Projects\ProjectTrace-local")
data = json.loads((ROOT / "baseline.json").read_text(encoding="utf-8"))
source = data["original_databases"]["30000"]["path"]
env = {
    **os.environ,
    "APP_ENV": "demo",
    "JOB_MODE": "sync",
    "PYTHONHASHSEED": "0",
    "PROJECTTRACE_PARSER_ISOLATION": "development",
    "SCALE001_PROTOTYPE_ROOT": str(ROOT),
    "PYTHONPATH": str(REPO),
}
env.pop("SCALE001_INDEX_TEST_MODE", None)
jobs = [
    [sys.executable, "-m", "tests.snapshot_materialization_probe", str(ROOT / "cold-original-147")],
    [sys.executable, "-m", "tests.graph_index_measure", source, str(ROOT / "update-original-30000"), "baseline"],
]
jobs += [
    [sys.executable, "-m", "tests.snapshot_component_probe", mode, str(ROOT / (mode + ".json")), "--database", source]
    for mode in ("sqlite_length", "sqlite_json", "sqlite_indexes", "hash_whole", "hash_stream")
]
jobs += [[sys.executable, str(ROOT / "structural_repro.py")]]
output = ROOT / "component-commands.json"
if output.exists():
    raise ValueError("Never overwrite measurements.")
rows = []
for command in jobs:
    result = subprocess.run(command, cwd=REPO, env=env, capture_output=True, text=True, encoding="utf-8", timeout=600)
    rows.append({"command": command, "exit_code": result.returncode, "stdout": result.stdout, "stderr": result.stderr})
    output.write_text(json.dumps(rows, indent=2), encoding="utf-8")
    print(
        json.dumps(
            {
                "step": len(rows),
                "total": len(jobs),
                "exit_code": result.returncode,
                "tail": result.stdout[-700:],
                "error": result.stderr[-700:],
            }
        ),
        flush=True,
    )
    if result.returncode:
        raise SystemExit(result.returncode)
