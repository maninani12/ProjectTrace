"""Append the current local continuation record without rewriting the report prefix."""

import hashlib
import json
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPO = Path(r"C:\Users\sai krishna\Projects\ProjectTrace-local")
REPORT = REPO / "docs/SCALE001_GENERATION_MAPS_LOCAL_TECHNICAL_REPORT.md"
RECEIPT = ROOT / "scale-report-append-receipt.json"
EXPECTED_HEAD = "9e21509591bfa5457cc829ebd5637f95be68d573"
APPENDIX = r'''

## Commercial V1 local continuation — 2026-10-29

This appendix records the local Windows development continuation on branch
`codex/scale-001-local-continuation`, unchanged HEAD
`9e21509591bfa5457cc829ebd5637f95be68d573`. It is not a Linux/cgroup result,
release approval, or certification of the dirty tree by historical CI.

### Expiry ownership and recovery correction

The local reaper could delete expiring encrypted analysis inputs, checkpoints,
or publication drafts while a live worker still owned the job lease. A related
expired input could leave a stale renewable queue token. `backend/retention.py`
adds transaction-local ownership checks coordinated with scheduling locks.
Checkpoint, draft, generation-chunk, and queue cleanup select bounded metadata,
recheck the lease under lock, and fence reclaimed work. Existing expiry/read
deadlines and cleanup page sizes are unchanged. Published receipts, snapshots,
history, encryption/HMAC formats, and schema 0026 were preserved.

Local test receipts: `retention-final.xml` (29 passed),
`retention-expanded.xml` (54 passed, one optional PostgreSQL test skipped),
`checkpoint-regressions.xml` (60 passed), and
`generation-regressions.xml` (34 passed). The skip means actual PostgreSQL row
lock behavior is not verified. Docker's local Linux daemon was unavailable and
no disposable PostgreSQL service was configured. A populated v2 database still
refuses downgrade; historical rows or markers were not rewritten.

### Local Commercial V1 workflow coverage

The final cold/warm/incremental owned workload completed three snapshots with
integrity check `ok`, zero foreign-key violations, three published generations,
and two pointers. Its output comparator returned `equal: true` against the
existing full cold/warm/incremental owned comparison. Separate cold output
comparisons against the profiled and quiet-profile runs also returned
`equal: true`. These results cover 147 owned metrics and fixture-scale output;
the jobs are PARTIAL under the existing repository coverage semantics and do
not establish pinned-repository completion.

The existing analyzer/security/graph result groups were respectively 95 tests
in `commercial-rules.xml`, 87 in `maps-and-exports.xml`, and 29 in
`security-and-graph.xml`. Frontend unit tests passed 49/49; production build
passed with 42 prerendered public routes. An owned browser run passed the
authentication drift and real ZIP-import flows. A new storage configuration
drift fixture adds a second narrow end-to-end path: a declared production
public ACL changes a documented “storage is private” claim from UNVERIFIED to
CONTRADICTED. The claim retains `DECLARED_CONFIGURATION` scope and explicitly
states that deployed runtime is unobserved. Its API regression command passed
7/7 selected tests; the owned browser test passed 1/1. Private, missing,
development-only, and commented declarations stay UNVERIFIED. No generic
configuration verifier or parser privilege was added.

Final Ruff check passed for `backend analyzers integrations workers tests
scripts integration_tests`; Python `compileall` passed for the same directories.
All commands were local. No commit, push, PR edit, remote workflow, merge,
deployment, or full Linux qualification occurred.

### Preserved blocker and next gate

The 50,000-metric snapshot reproduction still fails the original
1,000,000-node sanitizer guard. No guard or memory/time/checkpoint quota was
raised. Original graph indexes remain in place; disposable scalar/index
prototypes remain rejected. The original four owned databases were read-only
audited after this work: bytes match their captured SHA-256 values, SQLite
integrity is `ok`, foreign-key violations are zero, and published generation/
pointer counts are unchanged. The baseline audit checked 632 pre-existing
nonignored files; only four intentional post-baseline cleanup-function edits
were found among those existing paths.

ADR 0007's authenticated permanent snapshot-segment proposal remains
**PROPOSED** because the user requested proposal review first. No segmented
snapshot format, schema, reader, or admission policy was implemented. The next
engineering gate is review and explicit resolution of the proposed snapshot
contract, followed by an independently authorized implementation/validation
plan. PostgreSQL/Redis/Celery recovery and the full 768,000,000-byte, zero-swap
Linux pinned workload remain unverified. **SCALE-001 — NOT QUALIFIED.**

Detailed local status is in `PROJECTTRACE_PROGRESS.md` and
`docs/COMMERCIAL_V1_RELEASE_GATES.md`. Raw local receipts are packaged under
`docs/evidence/PROJECTTRACE_COMMERCIAL_V1_LOCAL_2026_10_29_RAW.tar.gz`; the
summary and package hashes are in the adjacent JSON receipt.
'''


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git(*args):
    return subprocess.check_output(["git", *args], cwd=REPO).decode().strip()


def main():
    if RECEIPT.exists():
        raise ValueError("Never overwrite the append receipt.")
    if git("branch", "--show-current") != "codex/scale-001-local-continuation":
        raise ValueError("Unexpected branch.")
    if git("rev-parse", "HEAD") != EXPECTED_HEAD:
        raise ValueError("Unexpected HEAD.")
    with REPORT.open("rb") as stream:
        before_hash = hashlib.file_digest(stream, "sha256").hexdigest()
        stream.seek(0, 2)
        before_size = stream.tell()
    encoded = APPENDIX.encode("utf-8")
    with REPORT.open("ab") as stream:
        stream.write(encoded)
        stream.flush()
    with REPORT.open("rb") as stream:
        prefix = stream.read(before_size)
        stream.seek(0, 2)
        final_size = stream.tell()
        stream.seek(0)
        final_hash = hashlib.file_digest(stream, "sha256").hexdigest()
    result = {
        "path": str(REPORT),
        "previous_prefix_bytes": before_size,
        "previous_prefix_sha256": before_hash,
        "prefix_unchanged": sha(prefix) == before_hash,
        "appendix_bytes": len(encoded),
        "final_bytes": final_size,
        "final_sha256": final_hash,
        "branch": git("branch", "--show-current"),
        "head": git("rev-parse", "HEAD"),
    }
    RECEIPT.write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
