"""Fresh source/data preservation baseline; never opens an original DB writable."""

import hashlib
import json
import platform
import sqlite3
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPO = Path(r"C:\Users\sai krishna\Projects\ProjectTrace-local")


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def git(*args):
    return subprocess.check_output(["git", *args], cwd=REPO)


def main():
    target = ROOT / "baseline.json"
    if target.exists():
        raise ValueError("Never overwrite a baseline.")
    paths = set(git("ls-files", "--cached", "--others", "--exclude-standard", "-z").decode().split("\0")) - {""}
    files = {name: sha(REPO / name) for name in sorted(paths) if (REPO / name).is_file()}
    earlier = json.loads((ROOT.parent / "graph-scalar-prototype-20261027/preserved.json").read_text(encoding="utf-8"))
    databases = {}
    for label, name in earlier["databases"].items():
        path = Path(name)
        before = sha(path)
        assert before == earlier["database_sha256"][name]
        with sqlite3.connect("file:" + path.as_posix() + "?mode=ro", uri=True) as db:
            databases[label] = {
                "path": name,
                "sha256": before,
                "integrity": db.execute("PRAGMA integrity_check").fetchone()[0],
                "foreign_keys": db.execute("PRAGMA foreign_key_check").fetchall(),
                "generations": db.execute("SELECT state,count(*) FROM analysis_generations GROUP BY state").fetchall(),
                "pointers": db.execute("SELECT count(*) FROM published_generations").fetchone()[0],
            }
        assert sha(path) == before
    result = {
        "head": git("rev-parse", "HEAD").decode().strip(),
        "branch": git("branch", "--show-current").decode().strip(),
        "status": git("status", "--short").decode(),
        "tracked_diff_sha256": hashlib.sha256(git("diff", "--binary")).hexdigest(),
        "source_files": files,
        "original_databases": databases,
        "environment": {"python": sys.version, "platform": platform.platform(), "sqlite": sqlite3.sqlite_version},
        "original_graph_indexes_required": True,
        "rejected_prototype_plugins_enabled": False,
    }
    assert result["head"] == "9e21509591bfa5457cc829ebd5637f95be68d573"
    assert result["branch"] == "codex/scale-001-local-continuation"
    target.write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps({"head": result["head"], "files": len(files), "databases": databases}))


if __name__ == "__main__":
    main()
