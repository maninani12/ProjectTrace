# ProjectTrace Commercial V1 — durable local checkpoint

Status: **DEVELOPMENT IN PROGRESS**. **SCALE-001 — NOT QUALIFIED.**

## 2026-10-27 — Master directive, baseline established

- Branch: `codex/scale-001-local-continuation`.
- HEAD: `9e21509591bfa5457cc829ebd5637f95be68d573`; no commits/pushes/workflows authorized.
- Existing dirty tree: nine tracked files modified plus retained untracked
  checkpoint, generation-map, streaming-export and rejected experiment files.
- Fresh baseline hashes **632 existing tracked/untracked nonignored files**;
  this replaces historical source-count assumptions. No existing source was
  changed when recording the baseline.
- Four original databases remain byte-identical to the prior preservation
  evidence. Each passes SQLite/FK checks. The 147-metric and prior fixture each
  retain three PUBLISHED generations and two pointers; the 10k/30k fixtures each
  retain one PUBLISHED generation and one pointer.
- Baseline evidence/work root:
  `C:\Users\sai krishna\Documents\Codex\2026-10-25\you-are-taking-over-projecttrace-development\work\commercial-v1-20261027-01`.
  `baseline.json` contains all file hashes, database hashes, status and environment.

## Coordinated execution plan

1. Revalidate focused baseline checkpoint/recovery and documentation-verdict
   tests without enabling any rejected graph-index plugin.
2. Profile original production-equivalent snapshot serialization, compilation,
   parameter binding, fetch/hydration, native index evaluation and owned cold
   publication. Keep original graph indexes/read SQL. Stop index experiments
   unless a new measured removable redundancy is established.
3. Reproduce the 50k structural guard failure, trace all snapshot consumers,
   and write an architecture decision if segmentation crosses a persistence/API
   boundary. Do not deploy a speculative new snapshot contract.
4. Investigate expiry/downgrade and lease/recovery behavior with disposable
   fixtures; reproduce defects before changing production code.
5. Audit and validate the existing documentation-drift vertical slice and its
   React integration. Reuse existing modules and labeled fixtures.
6. Update the release matrix and this checkpoint after each completed milestone.

## Current verified / failed / not run

- VERIFIED: fresh preservation baseline and SQLite/FK integrity only for this
  new execution batch. Prior test outcomes remain historical until rerun.
- FAILED, historical: 50k inline sanitizer guard; graph-index experiments
  rejected (last experiment 91 passed / 8 failed plus HTTP ordering failures).
- NOT_RUN: new baseline tests/profiles, full pinned Linux cgroup qualification,
  PostgreSQL/Redis/Celery/Docker checks, browser acceptance, deployment/recovery
  on the target production host.
- No production module, migration or resource guard changed in this batch yet.

## Exact next action

Run the focused baseline tests and prepare the original-path profiler in the
new work root. Frontend dependencies are absent in this checkout; install only
the project's locked frontend development dependencies with lifecycle scripts
disabled before running its existing unit tests/build. Full pinned Linux,
remote workflows, commits/pushes and production changes still require approval.

## Milestone 1 — baseline and frontend validation

- Backend baseline: **67 passed**, 0 failed/0 skipped, 532.20 s pytest time.
  Commands/results: `baseline-tests.json`, `baseline-tests.xml` in the work root.
  Covers existing migrations, generation contexts, the 10k/50k map decryption
  regressions and captured documentation/authentication drift/recovery.
- Frontend: locked dependencies installed with lifecycle scripts disabled;
  **49 passed**, 0 failed/pending; production build passed and prerendered 42
  public routes. Node v24.16.0. This is not browser or deployment acceptance.
- Frontend package/lock/source remain unchanged. No rejected prototype plugin
  was enabled in the baseline tests.

## Milestone 2 — expiry ownership defect reproduced and corrected

- Confirmed: active/cancel-pending worker recovery input/checkpoints/drafts
  could be deleted by expiry; unowned expired queue tokens remained renewable.
- Correct red suite: **9 failed / 12 passed**. The initial 12-failure receipt
  includes three invalid-fixture failures correctly rejected by tenant guards;
  those were corrected to explicit disposable legacy-corruption fixtures.
- First corrected suite: **21 passed**, 0 failed/skipped, 15.95 s pytest time.
- New `backend/retention.py` shares transaction-local scheduler/queue-row
  ownership locking. Existing cleanup batch sizes and retention/read deadlines
  remain unchanged. Cancel-pending live owners stay protected until fenced.
- `analysis_checkpoints.py`, `publication_units.py`, `generations.py`, and
  `queue.py` now select bounded metadata for cleanup, recheck ownership under
  locks, preserve receipts/public history, and fence reclaimed input attempts.
  No receipt version/digest, snapshot, graph index, HMAC or encryption format
  was changed. Existing uncommitted code outside targeted cleanup functions is
  retained. New regression file: `tests/test_retention_recovery.py`.
- Remaining verification before treating this slice as complete: renewal-race
  tests, generation-page/history cleanup, wider scheduler/checkpoint/recovery
  suites, and real PostgreSQL lock behavior. No PostgreSQL result is claimed.

## In progress / next safe actions

- Original-index owned CPU profile: `tests/commercial_snapshot_profile.py`,
  fresh output `cpu-original-147`; instrumented timings are not baseline speed
  or Linux/cgroup qualification.
- Then run same-input original 30k SQLite components and the existing 50k
  fail-closed guard case. Do not resurrect rejected index designs.
- Complete lease/race tests and relevant regressions after profiling, using new
  basetemps. Record snapshot-segmentation and retained-v2 downgrade decisions
  explicitly; neither is resolved by raising guards or rewriting receipts.
- Audit/validate the existing documentation drift vertical slice, including an
  owned browser run if existing service ports/browsers permit safe isolation.

**SCALE-001 — NOT QUALIFIED. Commercial V1 — DEVELOPMENT IN PROGRESS.**

## Milestone 3 — recovery verification and compatibility boundary

- `retention-expanded.xml`: **54 passed, 1 skipped**, 92.50 s. The explicit
  skip is `test_retention_postgresql.py`: no disposable PostgreSQL service is
  authorized/configured. Real row-lock behavior is NOT VERIFIED.
- `checkpoint-regressions.xml`: **60 passed**, 75.63 s; checkpoint pages,
  v1/v2 load, key rotation, cancellation, publication units and context replay.
- `generation-regressions.xml`: **34 passed**, 204.74 s; all existing generation
  restart/publication/final-commit cases on the corrected code.
- Final focused `retention-final.xml`: **29 passed**, 13.18 s; adds both lease
  renewal races, terminal-history preservation, rollback after deletion,
  non-starvation behind 1,000 protected orphan pages, metadata-only selection
  and real admitted-v2 normal-expiry/downgrade refusal.
- An intermediate metadata-only test exposed a remaining `discard` full-row
  checkpoint SELECT. Replaced it with tenant-scoped DELETE; the test was not
  weakened. Current tests pass after this correction.
- New operations guide: `docs/CHECKPOINT_RETENTION_AND_ROLLBACK.md`. Retained v2
  history still blocks downgrade. No format flag or receipt was reset/deleted
  to simulate compatibility. Migration 0026 itself is unchanged.

## Milestone 4 — original-index profiling and structural decision

- Two owned 147-metric cProfile runs completed with original graph indexes;
  one disables the diagnostic background sampler. Both have profiling overhead
  and are not production speed measurements. JSON, compile/bind, fetch, typed
  hydration and crypto function counts/times are recorded in `cpu-attribution.json`.
- Fresh same-value 30k UPDATE: 0.511612 s, native SQLite peak 342,798,624 bytes,
  process peak 393,408,512 bytes in that micro-operation process. This is not a
  complete 30k analysis/cgroup measurement. All eight sequential component/
  reproduction commands exited 0 and retained the original indexes/data.
- Direct 50k snapshot sanitizer reproduction: original 1,000,000-node guard
  rejects it, peak RSS 126,091,264 bytes, 2.463443 s. This is direct guard evidence,
  not a fresh full-job publication attempt. No resource limit was increased.
- Stop speculative index redesign. Native expression evaluation still consumes
  substantial memory; Python-side object reuse cannot make the SQLite API stop
  parsing the full bound JSON while keeping those expressions/contracts.
- ADR 0007 proposes permanent authenticated segmented snapshots and lists all
  persistence/API/expiry/backup compatibility obligations. **User answered
  "Review proposal first". No approval to implement that format was given.**
  Do not implement segments, change snapshot formats or perform a migration.

## Milestone 5 — existing commercial workflow validation

- `commercial-rules.xml`: **95 passed**, 49.26 s: existing analyzer evolution,
  OpenAPI, authentication drift, accuracy guards and Engineering Changes tests.
- Existing browser auth-drift workflow passed (**1 passed**, 51.0 s) against
  fresh owned API/database/UI, not an existing private account. Current final
  browser run additionally exercises the real ZIP-import workflow.
- No frontend source or verifier behavior was rewritten. Reuse working modules.
- Release/module matrix: `docs/COMMERCIAL_V1_RELEASE_GATES.md` distinguishes
  narrow verified workflows, partial modules, unsupported generic configuration
  claims and production/distributed qualification gaps.

## Milestone 6 — supported storage configuration drift

- Reused the existing `storage_claims` parser/inventory path. It reports an
  explicit supported production public ACL as CONTRADICTED within declared
  configuration scope. Private, absent, development-only, commented, or
  unsupported declarations remain UNVERIFIED; no runtime claim is made.
- Added `samples/configuration-drift.json` and
  `tests/test_configuration_drift.py`. The fixture captures the same immutable
  documentation claim against private BASE and public HEAD Terraform. The API
  test verifies the UNVERIFIED → CONTRADICTED transition, source hashes and
  evidence, `DECLARED_CONFIGURATION` scope, unchanged BASE, no imported-code
  execution, and cross-tenant denial.
- Focused command receipt `configuration-drift-final.json`: **7 passed**,
  including the new classification/API tests and existing native-platform and
  Engineering Changes regressions. The first attempt failed during pytest temp
  directory setup because the shared Windows temp path was inaccessible; a
  second run exposed an invalid test expectation about evidence on an
  UNVERIFIED claim. The final test compares immutable snapshot hashes and passed
  without altering product behavior or relaxing assertions.
- Added `frontend/e2e/configuration-drift.spec.ts`. Owned browser receipt
  `configuration-drift-browser-command.json`: **1 passed**; the UI displayed
  BASE/HEAD statuses and opened the captured `main.tf` evidence. The test used
  an isolated SQLite backend and owned Vite process, stopped after completion.
- Final static receipts `ruff-final.json` and `compile-final.json`: Ruff passed
  across backend, analyzers, integrations, workers, tests, scripts and
  integration_tests; Python compileall passed for the same paths. The browser
  run compiled and exercised its TypeScript test.
- Updated `docs/COMMERCIAL_V1_RELEASE_GATES.md`: this narrow storage workflow is
  verified locally; generic file/key configuration assertions and runtime
  authority remain unimplemented/unverified. This does not certify commercial
  release or production accuracy.

## Current next safe checkpoint

The local receipts are packaged at
`docs/evidence/PROJECTTRACE_COMMERCIAL_V1_LOCAL_2026_10_29_REVIEWED_V2.json` and
`docs/evidence/PROJECTTRACE_COMMERCIAL_V1_LOCAL_2026_10_29_REVIEWED_V2_RAW.tar.gz`.
The final source/database audit passed; the appended SCALE report prefix was
byte-verified unchanged. The ADR 0007 review is recorded in the proposal:
segmentation per object cannot admit the reproduced 50k logical snapshot while
preserving a global 1,000,000-node cap. That policy conflict and the durable
transaction/reader contract must be resolved before implementation. SCALE-001
remains NOT QUALIFIED; Commercial V1 remains DEVELOPMENT IN PROGRESS.
