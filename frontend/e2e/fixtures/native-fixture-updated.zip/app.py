from fastapi import FastAPI
from starlette.middleware.sessions import SessionMiddleware
app=FastAPI()
import jwt
jwt.decode(token,key)
DATABASE_URL='postgresql://user:example@localhost/demo'
@app.get('/health')
def health(): return True
def unsafe(db, x): return db.execute(f'SELECT * FROM users WHERE id={x}')
def complex(x):
    if x == 0: x += 1
    if x == 1: x += 1
    if x == 2: x += 1
    if x == 3: x += 1
    if x == 4: x += 1
    if x == 5: x += 1
    if x == 6: x += 1
    if x == 7: x += 1
    if x == 8: x += 1
    if x == 9: x += 1
    if x == 10: x += 1
    if x == 11: x += 1
